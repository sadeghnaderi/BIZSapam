﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BizSapam.Models;

namespace BizSapam.ViewModels
{
    public class InvoiceItems
    {
        public List<Tbl_InvoiceItems> InvoiceItem { get; set; }
    }
}