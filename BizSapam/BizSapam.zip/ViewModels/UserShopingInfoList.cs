﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BizSapam.ViewModels
{
    public class UserShopingInfoList
    {
        public List<UserShopingInfo> UsersInfo { get; set; }

        public UserShopingInfo UserInfo { get; set; }
    }
}