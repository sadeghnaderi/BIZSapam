﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BizSapam.Models
{
    public class Tbl_AccessLevels
    {
        public byte Id { get; set; }
        public string AccessType { get; set; }
    }
}