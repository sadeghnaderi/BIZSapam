﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BizSapam.Models
{
    public class CustomersRemainBalance
    {
        public string Name { get; set; }

        public string RemainBalance { get; set; }
    }
}